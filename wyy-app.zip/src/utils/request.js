import axios from 'axios'

const request = axios.create({
    baseURL: process.env.REACT_APP_BASEURL
})

request.interceptors.response.use(
    config=>{
        const {data} = config

        return Promise.resolve(data)
    },  
    error =>{
        return Promise.reject(error.response)
    }
)

export default request