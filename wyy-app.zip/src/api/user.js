import request from '../utils/request'
const cookie = localStorage.getItem('token')
// 短信登录
export const loginPhone = (params) => {
  return request({
    url: '/login/cellphone',
    method: 'get',
    params
  })
}

// 登录状态
export const loginStatus = () => {
  return request({
    url: '/daily_signin',
    method: 'get',
    params: {cookie}
  })
}
