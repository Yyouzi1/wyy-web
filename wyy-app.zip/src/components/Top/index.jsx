import React, { useState,useEffect } from 'react'
import { Input, Button, Modal, Form, message } from 'antd'
import { SearchOutlined } from '@ant-design/icons'
import { loginPhone,loginStatus } from '../../api/user'
import md5 from 'js-md5'
const Index = () => {
    const layout = {
        labelCol: {
            span: 5,
        },
        wrapperCol: {
            span: 16,
        },
    };
    useEffect(() => {
        loginStatus().then(res=>{
            console.log(res)
        })
    }, [])
    const tailLayout = {
        wrapperCol: {
            offset: 8,
            span: 12,
        },
    };
    const onFinish = values => {

        setLoading(true)
        const { phone, password } = values
        const params = {
            phone,
            md5_password: md5(password)
        }
        loginPhone(params).then(res => {
            setLoading(false)
            if (res.code !== 200) {
                message.error(res.message)
            }
            if (res.token) {
                localStorage.setItem('token', res.token)
                message.success('登录成功');
                setVisible(false)
            }

        })
    };
    const goToSearchPage = (e) => {
        window.open(`#/search/${e.target.value}`, '_self')
    }
    const [visible, setVisible] = useState(false)
    const [loading, setLoading] = useState(false)
    return (
        <div className="top-container">
            <div className="left-box">
                <div className="icon-wrapper">
                    <span
                        onClick={() => window.history.go('/')}
                        className="iconfont icon-home"
                    ></span>
                    <span className="iconfont icon-sami-select"></span>
                    <span className="iconfont icon-full-screen"></span>
                </div>
                <div className="history-wrapper">
                    <span
                        onClick={() => window.history.go(-1)}
                        className="iconfont icon-arrow-lift"
                    ></span>
                    <span
                        onClick={() => window.history.go(1)}
                        className="iconfont icon-arrow-right"
                    ></span>
                </div>
            </div>
            <div className="right-box">
                <Input
                    size="middle"
                    prefix={<SearchOutlined />}
                    placeholder="搜索"
                    onPressEnter={goToSearchPage}
                ></Input>
                <Button style={{ 'margin-left': '20px' }} onClick={() => { setVisible(true) }}>登录</Button>
                <Modal
                    title="登录"
                    visible={visible}
                    footer={null}
                >
                    <Form
                        {...layout}
                        name="basic"
                        initialValues={{
                            remember: true,
                        }}
                        onFinish={onFinish}
                    >
                        <Form.Item
                            label="Phone"
                            name="phone"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your phone!',
                                },
                            ]}
                        >
                            <Input />
                        </Form.Item>

                        <Form.Item
                            label="Password"
                            name="password"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your password!',
                                },
                            ]}
                        >
                            <Input.Password />
                        </Form.Item>
                        <Form.Item {...tailLayout}>
                            <Button onClick={() => { setVisible(false) }}>
                                取消
        </Button>
                            <Button loading={loading} style={{ 'margin-left': '20px' }} type="primary" htmlType="submit">
                                登录
        </Button>
                        </Form.Item>
                    </Form>
                </Modal>
            </div>
        </div>
    )
}
export default Index;