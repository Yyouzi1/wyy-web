export const GET_BANNER_DATA = 'discovery/GET_BANNER_DATA';
export const GET_RECOMMEND_DATA = 'discovery/GET_RECOMMEND_DATA';
export const GET_NEWSONG_DATA = 'discovery/GET_NEWSONG_DATA';
export const GET_MV_DATA = 'discovery/GET_MV_DATA';