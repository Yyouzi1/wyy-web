import Mv from './Mv'
import NewSong from './NewSong'
import Recommend from './Recommend'
import Swiper from './Swiper'
export {
    Mv, NewSong, Recommend, Swiper
}